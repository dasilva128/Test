import logging
import asyncio
import signal
import sys
from app.bot import bot, dp
from app.routers import build_router
from app.core.db import init_db

# تنظیم لاگینگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# پرچم برای خاموشی آرام
shutdown_event = asyncio.Event()

def signal_handler(signum, frame):
    """مدیریت سیگنال برای خاموشی آرام"""
    logger.info(f"سیگنال {signum} دریافت شد، شروع خاموشی...")
    shutdown_event.set()

async def _run():
    try:
        # راه‌اندازی پایگاه داده
        logger.info("راه‌اندازی پایگاه داده...")
        await init_db()
        logger.info("پایگاه داده راه‌اندازی شد")
        
        # شروع بات
        logger.info("شروع بات...")
        await dp.start_polling(bot, stop_signals=())
        
        # انتظار برای سیگنال خاموشی
        await shutdown_event.wait()
        
        # خاموشی آرام
        logger.info("توقف بات...")
        await bot.session.close()
        logger.info("بات متوقف شد")
        
    except Exception as e:
        logger.error(f"خطا در شروع: {e}")
        sys.exit(1)

def main():
    # ثبت مدیریت‌کننده‌های سیگنال
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # اتصال روترها
        dp.include_router(build_router())
        logger.info("روترها متصل شدند")
        
        # شروع چرخه اصلی
        asyncio.run(_run())
    except KeyboardInterrupt:
        logger.info("سیگنال قطع دریافت شد")
    except Exception as e:
        logger.error(f"خطای بحرانی: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()