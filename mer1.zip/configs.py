# configs.py
import os

API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
SESSION_NAME = os.getenv("SESSION_NAME", "video_merge_bot")
MONGODB_URI = os.getenv("MONGODB_URI", "")
LOG_CHANNEL = int(os.getenv("LOG_CHANNEL", "0"))  # optional
DOWN_PATH = os.getenv("DOWN_PATH", "downloads")
MAX_VIDEOS = int(os.getenv("MAX_VIDEOS", "10"))
TIME_GAP = int(os.getenv("TIME_GAP", "5"))  # seconds between requests per user
PROGRESS = os.getenv("PROGRESS", "Progress: {0}%\\n{1}/{2} ({3}/s)")
STREAMTAPE_API_USERNAME = os.getenv("STREAMTAPE_API_USERNAME", "")
STREAMTAPE_API_PASS = os.getenv("STREAMTAPE_API_PASS", "")
CAPTION = os.getenv("CAPTION", "Merged by @{0}")
