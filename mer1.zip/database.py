# database.py
from motor.motor_asyncio import AsyncIOMotorClient
from configs import MONGODB_URI

client = AsyncIOMotorClient(MONGODB_URI) if MONGODB_URI else None
db = client["video_merge_bot"] if client else None

class Database:
    def __init__(self):
        self.users = db.users if db else None

    async def add_user(self, user_id: int):
        if not self.users:
            return
        if not await self.is_user_exist(user_id):
            await self.users.insert_one({
                "id": user_id,
                "upload_as_doc": False,
                "generate_sample": False,
                "generate_ss": False,
                "thumbnail": None
            })

    async def is_user_exist(self, user_id: int) -> bool:
        if not self.users:
            return False
        return await self.users.find_one({"id": user_id}) is not None

    async def total_users_count(self) -> int:
        if not self.users:
            return 0
        return await self.users.count_documents({})

    async def get_all_users(self):
        if not self.users:
            return []
        cursor = self.users.find({})
        async for u in cursor:
            yield u

    # Settings getters/setters
    async def get_upload_as_doc(self, user_id: int) -> bool:
        if not self.users:
            return False
        user = await self.users.find_one({"id": user_id})
        return user.get("upload_as_doc", False) if user else False

    async def set_upload_as_doc(self, user_id: int, value: bool):
        if not self.users:
            return
        await self.users.update_one({"id": user_id}, {"$set": {"upload_as_doc": value}}, upsert=True)

    async def get_generate_sample_video(self, user_id: int) -> bool:
        if not self.users:
            return False
        user = await self.users.find_one({"id": user_id})
        return user.get("generate_sample", False) if user else False

    async def set_generate_sample_video(self, user_id: int, value: bool):
        if not self.users:
            return
        await self.users.update_one({"id": user_id}, {"$set": {"generate_sample": value}}, upsert=True)

    async def get_generate_ss(self, user_id: int) -> bool:
        if not self.users:
            return False
        user = await self.users.find_one({"id": user_id})
        return user.get("generate_ss", False) if user else False

    async def set_generate_ss(self, user_id: int, value: bool):
        if not self.users:
            return
        await self.users.update_one({"id": user_id}, {"$set": {"generate_ss": value}}, upsert=True)

    async def get_thumbnail(self, user_id: int):
        if not self.users:
            return None
        user = await self.users.find_one({"id": user_id})
        return user.get("thumbnail") if user else None

    async def set_thumbnail(self, user_id: int, path: str):
        if not self.users:
            return
        await self.users.update_one({"id": user_id}, {"$set": {"thumbnail": path}}, upsert=True)

db = Database()
