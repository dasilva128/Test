# Video Merge Bot - Project

This project contains a modular, production-ready Video Merge Telegram bot.
Files:
- bot.py (main)
- helpers.py (utility functions)
- database.py (MongoDB wrappers)
- configs.py (configuration)

Environment variables required:
- API_ID, API_HASH, BOT_TOKEN
- (optional) MONGODB_URI, DOWN_PATH, LOG_CHANNEL

Run:
1. install requirements:
   pip install -r requirements.txt
2. run:
   python bot.py
