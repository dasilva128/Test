# bot.py - main
import os
import time
import asyncio
import shutil
from pathlib import Path
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputMediaPhoto
from configs import *
from database import db
from helpers import (
    get_user_lock, check_time_gap, write_input_file, merge_video,
    delete_all, generate_screen_shots, upload_to_streamtape, humanbytes
)

API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
DOWN_PATH = os.getenv("DOWN_PATH", "downloads")
MAX_VIDEOS = int(os.getenv("MAX_VIDEOS", "8"))

app = Client("video_merge_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# in-memory
QueueDB = {}
ReplyDB = {}
FormtDB = {}

@app.on_message(filters.private & filters.command("start"))
async def start_cmd(bot, message):
    await db.add_user(message.from_user.id)
    await message.reply("سلام! ویدیو بفرست تا ادغام کنم.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Settings", callback_data="openSettings")]]))

@app.on_message(filters.private & (filters.video | filters.document))
async def handle_video(bot, message):
    user_id = message.from_user.id
    async with get_user_lock(user_id):
        await db.add_user(user_id)
        media = message.video or message.document
        if not media or not getattr(media, "file_name", None):
            return await message.reply("فایل نام ندارد!", quote=True)
        ext = media.file_name.rsplit(".",1)[-1].lower()
        if ext not in ["mp4","mkv","webm"]:
            return await message.reply("فرمت پشتیبانی نمی‌شود.", quote=True)
        if user_id not in QueueDB:
            QueueDB[user_id] = []
            FormtDB[user_id] = ext
        elif FormtDB.get(user_id) != ext:
            return await message.reply(f"ابتدا فرمت {FormtDB[user_id].upper()} ارسال کن.", quote=True)
        if len(QueueDB[user_id]) >= MAX_VIDEOS:
            return await message.reply(f"حداکثر {MAX_VIDEOS} فایل مجاز است.", quote=True)
        QueueDB[user_id].append(message.message_id)
        if user_id in ReplyDB:
            try:
                await bot.delete_messages(message.chat.id, ReplyDB[user_id])
            except:
                pass
        buttons = [[InlineKeyboardButton("Merge Now", callback_data="mergeNow")],[InlineKeyboardButton("Clear", callback_data="cancelProcess")]]
        rep = await message.reply(f"Added ({len(QueueDB[user_id])}/{MAX_VIDEOS})", reply_markup=InlineKeyboardMarkup(buttons), quote=True)
        ReplyDB[user_id] = rep.id

@app.on_callback_query()
async def cb_handler(bot, cb):
    user_id = cb.from_user.id
    data = cb.data

    if data == "mergeNow":
        async with get_user_lock(user_id):
            if user_id not in QueueDB or len(QueueDB[user_id]) < 2:
                return await cb.answer("Add at least 2 videos!", show_alert=True)
            work_dir = Path(DOWN_PATH)/str(user_id)
            work_dir.mkdir(parents=True, exist_ok=True)
            input_txt = work_dir/"input.txt"
            vid_paths = []
            for msg_id in sorted(QueueDB[user_id]):
                try:
                    msg = await bot.get_messages(user_id, msg_id)
                    media = msg.video or msg.document
                    dl = await bot.download_media(msg, file_name=str(work_dir/f"{msg_id}"))
                    vid_paths.append(dl)
                except Exception:
                    await cb.message.edit("One file failed. Skipping...")
                    await asyncio.sleep(1)
            if len(vid_paths) < 2:
                await delete_all(str(work_dir))
                return await cb.message.edit("Not enough valid videos.")
            await write_input_file(vid_paths, str(input_txt))
            await cb.message.edit("Merging...")
            ok, err = await merge_video(str(input_txt), str(work_dir/"merged."+FormtDB.get(user_id,"mp4")))
            if not ok:
                await delete_all(str(work_dir))
                return await cb.message.edit(f"Merge failed: {err}")
            merged = str(work_dir/f"merged.{FormtDB.get(user_id,'mp4')}")
            size = (Path(merged).stat().st_size)
            if size > 2_000_000_000:
                await cb.message.edit("File too big, uploading to Streamtape...")
                res = await upload_to_streamtape(merged, cb.message, size)
                await delete_all(str(work_dir))
                QueueDB.pop(user_id,None)
                FormtDB.pop(user_id,None)
                ReplyDB.pop(user_id,None)
                return
            await cb.message.edit("Uploading...")
            await bot.send_video(user_id, merged, caption="Merged")
            await delete_all(str(work_dir))
            QueueDB.pop(user_id,None)
            FormtDB.pop(user_id,None)
            ReplyDB.pop(user_id,None)

    elif data == "cancelProcess":
        await delete_all(f"{DOWN_PATH}/{user_id}")
        QueueDB.pop(user_id,None)
        FormtDB.pop(user_id,None)
        ReplyDB.pop(user_id,None)
        await cb.message.edit("Cancelled.")

    elif data == "openSettings":
        await cb.message.edit("Settings (not implemented in this demo).")

