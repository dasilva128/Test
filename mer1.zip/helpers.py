# helpers.py
import os
import time
import asyncio
import shutil
import shlex
from pathlib import Path
from typing import List, Tuple, Optional, Dict
import aiofiles
import aiohttp
from humanfriendly import format_timespan

from configs import Config if False else None  # placeholder for typing

# Local small implementations to avoid heavy deps in this example

GAP: Dict[str, float] = {}
user_locks: Dict[int, asyncio.Lock] = {}

def get_user_lock(user_id: int) -> asyncio.Lock:
    if user_id not in user_locks:
        user_locks[user_id] = asyncio.Lock()
    return user_locks[user_id]

async def check_time_gap(user_id: int, time_gap: int) -> Tuple[bool, int]:
    now = time.time()
    key = str(user_id)
    if key in GAP:
        prev = GAP[key]
        diff = int(now - prev)
        if diff < time_gap:
            return True, time_gap - diff
        else:
            del GAP[key]
    GAP[key] = now
    return False, 0

async def delete_all(root: str):
    try:
        p = Path(root)
        if p.exists() and p.is_dir():
            shutil.rmtree(root, ignore_errors=True)
    except:
        pass

# write input file safely for ffmpeg concat
async def write_input_file(paths: List[str], input_path: str):
    safe_lines = ["file " + shlex.quote(str(Path(p).resolve())) for p in paths]
    async with aiofiles.open(input_path, "w", encoding="utf-8") as f:
        await f.write("\\n".join(safe_lines))

# run ffmpeg concat
async def merge_video(input_file: str, output: str) -> Tuple[bool, str]:
    args = ["ffmpeg","-y","-f","concat","-safe","0","-i", input_file, "-c","copy", output]
    proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, err = await proc.communicate()
    return (proc.returncode == 0 and Path(output).exists()), (err.decode() if err else "")

async def generate_screen_shots(video_file: str, output_dir: str, count: int, duration: int):
    images = []
    if duration <= 0:
        return images
    step = max(1, duration // max(1,count))
    cur = step
    for i in range(count):
        out = os.path.join(output_dir, f"ss_{int(time.time())}_{i}.jpg")
        args = ["ffmpeg","-ss", str(cur), "-i", video_file, "-vframes","1","-q:v","2", out, "-y"]
        proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        if os.path.exists(out):
            images.append(out)
        cur += step
        await asyncio.sleep(0.2)
    return images

# streamtape uploader (simple, may need API keys)
async def upload_to_streamtape(file_path: str, editable, file_size: int):
    # This is a placeholder implementation. Implement actual API calls as needed.
    await editable.edit("Uploading to Streamtape (simulated)...")
    await asyncio.sleep(1)
    return {"url": f"https://streamtape.com/fake/{Path(file_path).name}"}

async def humanbytes(size: float) -> str:
    if not size:
        return "0 B"
    power = 1024
    n = 0
    labels = ['', 'Ki', 'Mi', 'Gi', 'Ti']
    while size >= power and n < len(labels)-1:
        size /= power
        n += 1
    return f"{round(size,2)} {labels[n]}B"
